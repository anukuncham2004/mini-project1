alert("app.js loaded");

const API_URL = "http://localhost:5000/api/tickets";

document.getElementById("ticketForm").addEventListener("submit", async (e) => {

  e.preventDefault();

  const title = document.getElementById("title").value;
  const description = document.getElementById("description").value;
  const priority = document.getElementById("priority").value;

  try {

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        title,
        description,
        priority
      })
    });

    const data = await response.json();

    console.log(data);

    alert("Ticket Created Successfully");

    document.getElementById("ticketForm").reset();

  } catch (error) {

    console.error(error);

    alert("Failed to create ticket");

  }

});